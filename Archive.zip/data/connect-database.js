'use strict'

const { Client } = require('cassandra-driver');